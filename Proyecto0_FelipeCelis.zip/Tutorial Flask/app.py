from flask import Flask, render_template, request, redirect, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

##Correr el programa en el comand window de gitbash 
#1 source virtaul/Scripts/activate
#2 export FLASK_APP=app.py (o como sea que se llame el archivo)
#3 export FLASK_ENV=development
#4 FLASK_DEBUG=1

app= Flask(__name__)
app.secret_key = "Proyecto0"

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'

db=SQLAlchemy(app)

#Create data base model
class tabla_clientes(db.Model):
    client_id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(80), nullable=False)
    password = db.Column(db.String(80), nullable=False)
    
    def __repr__(self):
        return '<tabla_clientes %r>' % self.client_id

#Relación One to many en client_id

class tabla_eventos(db.Model):
    evento_id = db.Column(db.Integer, primary_key=True)
    nombre_evento = db.Column(db.String(80), nullable=False)
    categoria = db.Column(db.String(80), nullable=False)
    direccion = db.Column(db.String(150), nullable=False)
    fecha_i = db.Column(db.DateTime, nullable=False)
    fecha_f = db.Column(db.DateTime, nullable=False)
    tipo = db.Column(db.String(80), nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey(tabla_clientes.client_id)) #Foreignkey
    ahora = db.Column(db.DateTime, default=datetime.now())
    
    def __repr__(self):
        return '<tabla_eventos %r>' % self.evento_id



#Pagina Principal.
#Si hay una sesión iniciada, redirige a la página de eventos, si no presenta los campos para iniciar sesión.
@app.route('/', methods=['POST', 'GET'])
def index(): 
    title='Eventos ABC!'

    if request.method == 'POST':

        password = request.form['password_login']
        correo = request.form['correo_usuario']

        if  tabla_clientes.query.filter_by(email=correo).first() is not None:
            if tabla_clientes.query.filter_by(email=correo).first().password == password:
                session["user"] = tabla_clientes.query.filter_by(email=correo).first().client_id
                return redirect("/eventos")
            else:
                error_statement= 'La contraseña es incorrecta'
                return render_template('fail_login.html',error_statement=error_statement)
        else:
            error_statement= 'El correo no esta registrado'
            return render_template('fail_login.html',error_statement=error_statement)
    else:
        if "user" in session:
            return redirect("/eventos")
        else:
            return render_template("index.html",title=title)

#Crea un nuevo usuario.
@app.route('/subscribe', methods=['POST','GET'])
def about(): 

    title='Crear nueva cuenta'

    if request.method=='POST':
        correo = request.form['correo_nuevo']
        password_n = request.form['password_new']
        password_v = request.form['password_new_v']

        if tabla_clientes.query.filter_by(email=correo).first() is None and password_n==password_v:
            ingresos = tabla_clientes(email=correo,password=password_n)
            db.session.add(ingresos)
            db.session.commit()
            return redirect("/")
        else: 
            error_statement= 'El correo ya existe o la contraseña no coincide'
            return render_template('fail_subscribe.html',error_statement=error_statement)
    else:
        return render_template("subscribe.html",title=title)


#Presenta los eventos del usuario, si no hay un sesión en curso, redirige a la pagina de login
@app.route('/eventos', methods=['POST','GET'])
def eventos(): 
    
    if "user" in session:

        title='Eventos'
        user = session["user"]

        eventos_act = tabla_eventos.query.filter_by(client_id=user).order_by(tabla_eventos.ahora.desc()).all()

        if request.method == 'POST':

            Categorias =[ 'Conferencia', 'Seminario', 'Congreso' , 'Curso']
            Tipos=['Presencial','Virtual']

            evento = request.form['evento']
            categoria =  request.form['categoria']
            if  categoria in Categorias:
                pass
            else:
                error_statement= 'Categorias Permitidas : Conferencia, Seminario, Congreso o Curso'
                return render_template('fail.html',error_statement=error_statement)
            direccion =  request.form['direccion']
            try:
                fecha_inicial =  datetime.strptime(request.form['fecha_inicial'], "%d/%m/%Y" )
                fecha_final =  datetime.strptime(request.form['fecha_final'], "%d/%m/%Y" )
            except:
                error_statement= 'El formato de fecha debe ser DD/MM/YYYY'
                return render_template('fail.html',error_statement=error_statement)
            tipo_evento = request.form['tipo_evento']
            if tipo_evento in Tipos:
                pass
            else:
                error_statement= 'Tipos Eventos Permitidos : Presencial o Virtual'
                return render_template('fail.html',error_statement=error_statement)

            ingresos=tabla_eventos(nombre_evento=evento,categoria=categoria,direccion=direccion,fecha_i=fecha_inicial,fecha_f=fecha_final,tipo=tipo_evento,client_id=user)
            
            db.session.add(ingresos)
            db.session.commit()

            return render_template("eventos.html",title=title, eventos_act=tabla_eventos.query.filter_by(client_id=user).all())

        else:
            return render_template("eventos.html",title=title, eventos_act=eventos_act )
    else:
        return redirect("/")


#Logout
@app.route('/logout')
def logout(): 
    if "user" in session:
        session.pop("user",None)
        return redirect("/")
    else:
        return redirect("/")

#Pagina de editar evento.
@app.route('/editar/<int:evento_id>', methods=['POST','GET'])
def editar(evento_id): 
    evento_editar = tabla_eventos.query.filter_by(evento_id=evento_id).first()
    title='Editar'
    if request.method == 'POST':
        try:
            evento_editar.nombre_evento = request.form["Evento"]
            evento_editar.categoria = request.form["categoria"]
            evento_editar.direccion = request.form["direccion"]
            evento_editar.fecha_i = datetime.strptime(request.form["fecha_i"],"%d/%m/%Y")#:%I:%M:%S")
            evento_editar.fecha_f = datetime.strptime(request.form["fecha_f"],"%d/%m/%Y")#:%I:%M:%S")
            evento_editar.tipo = request.form["tipo"]
            db.session.commit()
            return redirect("/eventos")
        except:
            error_statement= 'Eror en la base de datos, formato fecha'
            return render_template('fail.html',error_statement=error_statement)
    else:
        return render_template("editar.html",title=title,evento_editar=evento_editar)

#Funcion de eliminar evento
@app.route('/eliminar/<int:evento_id>', methods=['POST','GET'])
def eliminar(evento_id): 
    evento_eliminar = tabla_eventos.query.filter_by(evento_id=evento_id).first()
    db.session.delete(evento_eliminar)
    db.session.commit()
    return redirect("/eventos")
    

if __name__ == '__main__':

    app.run(debug=True)