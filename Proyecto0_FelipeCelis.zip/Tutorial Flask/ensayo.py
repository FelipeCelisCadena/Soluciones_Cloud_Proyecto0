from datetime import datetime

fecha_i='01/02/2021'

fecha_corr=datetime.strptime(fecha_i, "%d/%m/%Y")

print(fecha_corr)

Categorias =[ 'Conferencia', 'Seminario', 'Congreso' , 'Curso']

Entrada=input('Ingrese el evento')

if Entrada in Categorias:
    print('si')
else:
    print('no')

print(datetime.now())

# Clientes=[]
# @app.route('/form', methods=["POST"])
# def form():
#     ##
#     first_name= request.form.get('first_name')
#     last_name=  request.form.get('last_name')
#     email=  request.form.get('email')
#     ##
#     if len(first_name)<1 or len(last_name)<1 or len(email)<1:
#         error_statement= 'Debe llenar todos los campos del formulario'
#         return render_template('fail.html',error_statement=error_statement,
#         first_name=first_name,last_name=last_name,email=email)
#     ##
#     Clientes.append([first_name,last_name,email])
#     title = 'Gracias por susbribirse'
#     return render_template("form.html",title=title, first_name=first_name, last_name=last_name , email=email, Clientes=Clientes)


# @app.route('/subscribe')
# def subscribe():
#     title = 'Subscribe !!'
#     return render_template("subscribe.html",title=title)


# @app.route('/eventos', methods=['POST', 'GET'])
# def eventos(): 

#     title='Eventos'

#     Categorias =[ 'Conferencia', 'Seminario', 'Congreso' , 'Curso']
#     Tipos=['Presencial','Virtual']

#     if request.method == 'POST':

#         evento = request.form['evento']

#         categoria =  request.form['categoria']
#         if  categoria in Categorias:
#             pass
#         else:
#             error_statement= 'Categorias Permitidas : Conferencia, Seminario, Congreso o Curso'
#             return render_template('fail.html',error_statement=error_statement)
        
#         direccion =  request.form['direccion']
#         try:
#             fecha_inicial =  datetime.strptime(request.form['fecha_inicial'], "%d/%m/%Y" )
#             fecha_final =  datetime.strptime(request.form['fecha_final'], "%d/%m/%Y" )
#         except:
#             error_statement= 'El formato de fecha debe ser DD/MM/YYYY'
#             return render_template('fail.html',error_statement=error_statement)

        
#         tipo_evento = request.form['tipo_evento']
#         if tipo_evento in Tipos:
#             pass
#         else:
#             error_statement= 'Tipos Eventos Permitidos : Presencial o Virtual'
#             return render_template('fail.html',error_statement=error_statement)

#         ingresos=tabla_eventos(nombre=evento,categoria=categoria,direccion=direccion,fecha_i=fecha_inicial,fecha_f=fecha_final,tipo=tipo_evento)
#         # new_evento = data_base(nombre=evento)
#         # new_categoria = data_base(categoria=categoria)
#         # new_direccion = data_base(direccion=direccion)
#         # new_fehca_i = data_base(fecha_i = fecha_inicial)
#         # new_fecha_f = data_base(fecha_f = fecha_final)
#         # new_tipo = data_base(tipo=tipo_evento)

#         #try:
#         db.session.add(ingresos)
#         db.session.commit()
#         #    return redirect("/eventos")
#         #except:
#         return "Melo"
#     else:
#         eventos_actuales = tabla_eventos.query.all()
#         return render_template("eventos.html",title=title, eventos_act = eventos_actuales)